The following lexers (counting only important ones) exist for SynWrite. 
Most of them are not installed by default, they are located in Addons Manager "Install" list.

* ABAP
* Abaqus Keywords
* ABC Notation
* ActionScript
* Acu Cobol
* Ada
* Apache config
* Apache Hive
* Apache Pig
* AppleScript
* Arduino
* Assembly
* Assembly ARM
* Assembly AVR
* Assembly FASM
* Assembly JWASM
* Assembly MIPS
* Assembly SHARC DSP
* Assembly SPARC
* Assembly Z80 SjASM
* Asymptote
* AutoHotkey
* AutoIt
* Automake
* AviSynth
* AWK
* Bash script
* Batch files
* BibTeX
* Bitsquid SJSON
* Bohemia SQF
* Boo
* Brainfuck
* C
* C#
* C++
* Caffe Prototxt
* Caml
* Clarion
* Clavier
* Clipper
* Clojure
* CMake
* Cobol
* CodeVisionAVR
* CoffeeScript
* ColdFusion
* CRF files
* CSS
* CUDA C++
* D
* Dart
* Delphi resources
* Diff
* Dockerfile
* Eiffel
* Elixir
* Elm
* Erlang
* Euphoria
* F#
* Factor
* Forth
* Fortran
* FoxPro
* GAMS
* Gherkin
* GLSL
* Go
* Gold Parser
* Graphviz DOT
* GraphQL
* Great Cow Basic
* Groovy
* Haml
* Harbour
* Haskell
* Haxe
* HJSON
* HTML
* HTML Diafan
* HTML Django DTL
* HTML Embedded JS
* HTML Handlebars
* HTML Laravel Blade
* HTML Mustache
* HTML Siteleaf Liquid
* HTML Smarty
* IDL files
* IDL language
* Informix 4GL
* Ini files
* Inno Setup
* Intel HEX
* Jade
* Jasmine JVM Assembler
* Java
* Java Velocity
* JavaScript
* JavaScript Babel/ React JSX
* JCL
* Jinja2
* JSON
* Julia
* Kivy
* KiXtart
* Kotlin
* LaTeX
* LESS
* Lisp
* LiveCode script
* Log files
* Lola-2
* Lua
* Macro Scheduler script
* Makefile
* Markdown
* MATLAB
* MediaWiki
* Metafont
* MIB files
* Modelica
* Modula 2
* MSVS Solution
* MySQL
* Nemerle
* NFO files
* Nginx
* Nim
* nnCron
* NSIS
* NSL Assembler
* Oberon
* Objective-C
* OpenCL
* OpenEdge
* OpenSCAD
* Parser3
* Pascal
* Pawn
* Perl
* PHP
* PICL
* Pike
* PL/SQL
* PlantUML
* PostScript
* PowerShell
* Prolog
* Properties
* Puppet
* Python
* R
* R Markdown
* Racket
* Rainmeter
* Ragel
* Razor
* reStructuredText
* RPG/IV
* RTF (RichText)
* Ruby
* Rust
* Sass
* Scala
* Scheme
* SCSS
* Slim
* Smalltalk
* SQL
* Squirrel
* Standard ML
* Stata
* Strace
* Stylus
* Swift
* T-SQL
* TakeCommand
* Tcl/Tk
* Textile
* TOML
* Tree
* Twig
* TypeScript
* Vala
* VBScript
* Verilog HDL
* VHDL
* VimL (Vimscript)
* Virgil
* Visual Basic
* Visual dBase
* WinBuilder script
* Windows Resource Script
* WSH script
* XML
* XSLT
* Yacc (Bison)
* YAML 
* ZenScript (MineTweaker)
