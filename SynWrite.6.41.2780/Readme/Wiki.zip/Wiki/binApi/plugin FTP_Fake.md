**FTP_Fake** is dummy panel plugin. To activate it, you need to open file "SynPlugins.ini" in SynWrite folder, and register plugin there.

This plugin shows usage of SynWrite FTP API. It doesn't actually connect to internet, it only calls actions needed to open downloaded file, and implements action needed to upload file when user saves it in SynWrite.

Source code ships with SynWrite (in folder "Readme").
