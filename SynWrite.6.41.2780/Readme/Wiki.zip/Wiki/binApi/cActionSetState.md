This action can be called by plugin to indicate its current state in app panel title.
If passed non-empty string, this string is shown in panel title after plugin name, e.g. "FTP - ftp.test.com".

Parameters:

- **A1** (PWideChar) - state string (without plugin name).
- **A2** - not used.
- **A3** - not used.
- **A4** - not used.

Return value: not used.
