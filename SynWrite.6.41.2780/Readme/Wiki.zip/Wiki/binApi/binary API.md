This page describes API for SynWrite binary plugins.
Currently the following plugin types are supported:

- [binary Panel plugins]
- [binary Auto-Completion plugins]
- [binary Goto-Definition plugins]
- [binary Command plugins]

Notes

- The Delphi header file for plugins is included in SynWrite sources ("Readme\\Src.rar" archive, file "ATSynPlugins.pas").  
- The C++ header file for plugins is included in [SynFTP sources](https://sourceforge.net/projects/synwrite-addons/files/BinaryPlugins/).
