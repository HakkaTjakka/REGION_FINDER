This action can be called by plugin to show a message in SynWrite status bar.

Parameters:

- **A1** (PWideChar) - message string.
- **A2, A3, A4** - not used.

Return value: not used.
