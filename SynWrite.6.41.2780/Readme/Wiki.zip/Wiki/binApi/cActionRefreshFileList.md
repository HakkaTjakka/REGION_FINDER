This action can be called by SW to inform plugins that some file was deleted/renamed/created (one of commands are performed: "Close and delete"/"Rename"/"Save as").

Parameters:

- **A1** (PWideChar) - full file path.
- **A2, A3, A4** - not used.

Return value not used.
