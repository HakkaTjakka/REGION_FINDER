This action can be called by plugin to get caret position (0-based) in the current editor.

Parameters:

- **A1** (PInteger) - if not zero, points to value of X position (column).
- **A2** (PInteger) - if not zero, points to value of Y position (line).
- **A3** (PInteger) - if not zero, points to value of absolute text offset.
- **A4** - not used.

Return value: not used.

