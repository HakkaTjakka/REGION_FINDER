How to update Emmet's JS file
=============================

Clone https://github.com/emmetio/emmet  
In project folder:

    npm install
    gulp

In ./dist appears emmet.js  
Other files not needed
